<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?= $title; ?></title>
	<link rel="stylesheet" href="src/assets/css/main.css">
</head>

<body>
	<header id="header">
		<div class="wrapper">
			<div id="logo">
				<a href=""> LOGO</a>
			</div>
		</div>
	</header>
	<main class="wrapper">